from random import randint
def roll(dice):
	return randint(1,dice)
	

cat = 0
print(cat)
cat = roll(6)
print(cat)
cat = randint(1,6)
print(cat)

