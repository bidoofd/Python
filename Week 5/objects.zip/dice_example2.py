# Create a D6 as variable.
from random import randint

for a in range(0,10):
	die1 = randint(1, 6)
	print (die1)


