# Create a D6 variable.
from random import randint
die1 = randint(1, 6)
print (die1)




