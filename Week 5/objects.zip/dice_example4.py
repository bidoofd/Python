from die import Die

# Create a D6 object

die1 = Die()
for a in range(0,10):
	roll = die1.roll()
	print (roll)
