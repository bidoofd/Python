# Create a D6 function (show scope)
from random import randint
die1 = 0
def roll():
    die1 = randint(1, 6)

	
	


for a in range(0,10):
	roll()
	print (die1)
