import matplotlib.pyplot as graph

data = [10,15,13,17,20,33,12,17,24,33,9,32]
graph.plot(data)
graph.show()

